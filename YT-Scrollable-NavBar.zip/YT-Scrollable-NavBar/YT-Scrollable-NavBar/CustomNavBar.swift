//
//
//  CustomNavBar.swift
//  YT-Scrollable-NavBar
//
//  Created by Haipp on 15.03.22.
//  
	

import SwiftUI

struct CustomNavBar: View {
	var body: some View {
		HStack {
			Button(action: {}) {
				Text("Settings")
					.foregroundColor(.white)
			}
			
			Spacer()
			
			Button(action: {}) {
				Text("Add")
					.foregroundColor(.white)
			}
		}
		.font(.title2.bold())
		.padding(.vertical, 10)
		.padding(.horizontal)
		.frame(maxWidth: .infinity)
		.background(Color.red)
	}
}

struct CustomNavBar_Previews: PreviewProvider {
    static var previews: some View {
        CustomNavBar()
    }
}
