//
//
//  DynamicNavBarWithScrollView.swift
//  YT-Scrollable-NavBar
//
//  Created by Haipp on 15.03.22.
//  
	

import SwiftUI

struct DynamicNavBarWithScrollView<Content: View, NavBarContent: View>: View {
	
	@State private var scrollOffset: CGFloat = 0
	@State private var prevScrollOffset: CGFloat = 0
	@State private var navBarOffset: CGFloat = 0
	
	@State private var navBarHeight: CGFloat = 100 // Default Value
	
	let content: () -> Content
	let navBarContent: () -> NavBarContent
	
	init(navBar: @escaping () -> NavBarContent, content: @escaping () -> Content) {
		self.content = content
		self.navBarContent = navBar
	}
	
	var body: some View {
		GeometryReader { reader in
			ZStack {
				ScrollViewOffset(offsetChange: { offsetY in
					scrollOffset = offsetY
					updateNavBarOffset()
					prevScrollOffset = scrollOffset
				}) {
					content()
					.padding(.top, navBarHeight)
				}
				
				VStack {
					navBarContent()
						.padding(.top, reader.safeAreaInsets.top)
						.overlay {
							GeometryReader { frameReader in
								Color.clear
									.onAppear {
										navBarHeight = frameReader.size.height
									}
							}
						}
						.offset(y: navBarOffset)

					Spacer()
				}
				.zIndex(99)
			}
			.ignoresSafeArea(.all, edges: .top)
		}
		.background(Color.white)
	}
	
	func updateNavBarOffset() {
		if scrollOffset >= 0 {
			navBarOffset = 0
			return
		}
		let diff = scrollOffset - prevScrollOffset
		navBarOffset += diff
		navBarOffset = max(min(navBarOffset, 0), -navBarHeight)
	}
}

//struct DynamicNavBarWithScrollView_Previews: PreviewProvider {
//    static var previews: some View {
//        DynamicNavBarWithScrollView()
//    }
//}
