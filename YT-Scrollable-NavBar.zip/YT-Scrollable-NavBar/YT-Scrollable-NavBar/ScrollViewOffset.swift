//
//
//  ScrollViewOffset.swift
//  ExpenseTracker
//
//  Created by Haipp on 12.10.21.
//  


import SwiftUI


private struct OffsetPreferenceKey: PreferenceKey {
	static var defaultValue: CGFloat = .zero
	static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {}
}


struct ScrollViewOffset<Content: View>: View {
	
	let content: () -> Content
	let offsetChange: (CGFloat) -> Void
	
	init(offsetChange: @escaping (CGFloat) -> Void, @ViewBuilder content: @escaping () -> Content) {
		self.content = content
		self.offsetChange = offsetChange
	}
	
	var body: some View {
		ScrollView {
			offsetReader
			content()
				.padding(.top, -8)
		}
		.coordinateSpace(name: "scrollViewOffset")
		.onPreferenceChange(OffsetPreferenceKey.self, perform: offsetChange)
	}
	
	var offsetReader: some View {
		GeometryReader { proxy in
			Color.clear
				.preference(
					key: OffsetPreferenceKey.self,
					value: proxy.frame(in: .named("scrollViewOffset")).minY
				)
		}
		.frame(height: 0)
	}
}
