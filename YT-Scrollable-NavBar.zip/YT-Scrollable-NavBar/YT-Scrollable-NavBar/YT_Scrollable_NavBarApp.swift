//
//
//  YT_Scrollable_NavBarApp.swift
//  YT-Scrollable-NavBar
//
//  Created by Haipp on 15.03.22.
//  
	

import SwiftUI

@main
struct YT_Scrollable_NavBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
