//
//
//  ContentView.swift
//  YT-Scrollable-NavBar
//
//  Created by Haipp on 15.03.22.
//  
	

import SwiftUI

struct ContentView: View {
	var body: some View {
		DynamicNavBarWithScrollView(navBar: {
			CustomNavBar()
		}) {
			VStack(spacing: 10) {
				ForEach(0 ..< 20, id: \.self) { _ in
					RoundedRectangle(cornerRadius: 8)
						.frame(height: 300)
						.foregroundColor(.blue)
				}
			}
			.padding(.vertical, 10)
			.padding(.horizontal, 10)
		}
	}
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
